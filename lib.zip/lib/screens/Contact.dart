import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';

class Contact extends StatefulWidget {
  const Contact({super.key});

  @override
  State<Contact> createState() => _ContactState();
}

class _ContactState extends State<Contact> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child:const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('İşləmə saatları',style: TextStyle(
                color: colorHome,
                fontSize: 18,
                fontWeight: FontWeight.w700
            ),),
            Text('Bazar ertəsi:09:00/20:00'),
            Text('Şənbə:09:00/20:00'),
            SizedBox(height:15),
            Text('Ünvan',style: TextStyle(
              color: colorHome,
              fontSize: 18,
              fontWeight: FontWeight.w700
            ),),
            Text('Burada sizin magazanizin adres bilgileri yazilacaq'),
            SizedBox(height:15),
            Text('Email',style: TextStyle(
                color: colorHome,
                fontSize: 18,
                fontWeight: FontWeight.w700
            ),),
            Text('info@linzaplanet.az'),
            SizedBox(height:15),
            Text('Telefon',style: TextStyle(
                color: colorHome,
                fontSize: 18,
                fontWeight: FontWeight.w700
            ),),
            Text('+994(12)000 00 00'),
            Text('+994(55)000 00 00'),
            SizedBox(height:15),
          ],
        ),
      ),
    );
  }
}

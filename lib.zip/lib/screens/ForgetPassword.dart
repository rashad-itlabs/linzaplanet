import 'package:flutter/material.dart';

import '../component/color.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({super.key});

  @override
  State<ForgetPassword> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  final form_key = new GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: Container(
        color: Colors.white,
        padding: EdgeInsets.all(15),
        child: Center(
          child: Form(
            key: form_key,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Unudulmuş şifrənin bərpası',style:TextStyle(fontSize: 23)),
                const SizedBox(height: 10),
                const Text('E-mail adresi',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.mail_outline_rounded,color:colorHome,),
                    )
                  ],
                ),
                SizedBox(height: 15),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: (){},
                    child: Text('Daxil ol',style: TextStyle(color: Colors.white,
                        fontSize: 18),),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        minimumSize: Size(180,60),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                        )
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:linzaplanet/screens/LoginScreen.dart';

import '../component/color.dart';

class SearchProductDetail extends StatefulWidget {
  const SearchProductDetail({super.key});

  @override
  State<SearchProductDetail> createState() => _SearchProductDetailState();
}

class _SearchProductDetailState extends State<SearchProductDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network('https://linzaplanet.az/upload/flod_(2)1.jpg'),
            const Text('Acuvue OASYS 1-Day 30 Pack',style:TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.indigo
            ),),
            const SizedBox(height:15,),
            const Divider(height: 1,color:Colors.black12),
            const SizedBox(height: 15,),
            Padding(
              padding: const EdgeInsets.only(left: 8.0,right: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.question_answer_outlined,color: Colors.greenAccent,),
                      SizedBox(width:5,),
                      Text('Goz nomreleriniz ferqlidir?')
                    ],
                  ),
                  Row(
                    children: [
                      Container(
                        decoration:const BoxDecoration(
                            color: Color(0xc0eeeeee)
                        ),
                        child: TextButton(
                          onPressed: (){},
                          child:const Text('Beli',style: TextStyle(color:Colors.black45),),
                        ),
                      ),
                      Container(
                        decoration:const BoxDecoration(
                            color: Colors.greenAccent
                        ),
                        child: TextButton(
                          onPressed: (){},
                          child: Text('Xeyr',style: TextStyle(color: Colors.white),),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            const SizedBox(height:15,),
            const Divider(height: 1,color:Colors.black12),
            const SizedBox(height: 15,),
            const Padding(
              padding: EdgeInsets.only(left:15,right: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text('Bc',style: TextStyle(
                      color: colorHome,
                      fontWeight: FontWeight.w700
                  ),),
                  Text('Sph(Pwr)',style: TextStyle(
                      color: colorHome,
                      fontWeight: FontWeight.w700
                  ),),
                  Text('Eded',style: TextStyle(
                      color: colorHome,
                      fontWeight: FontWeight.w700
                  ),),
                ],
              ),
            ),
            // nomrelerin duzulmesi
            SizedBox(height:15),
            Padding(
              padding: EdgeInsets.only(left:15,right: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    child: Container(
                      width: 70,
                      height: 40,
                      decoration:const BoxDecoration(
                          border: Border(
                            left: BorderSide(color: Colors.black26,width: 1),
                            right: BorderSide(color: Colors.black26,width: 1),
                            top: BorderSide(color: Colors.black26,width: 1),
                            bottom: BorderSide(color: Colors.black26,width: 1),
                          )
                      ),
                      child:const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('8.8'),
                      ),
                    ),
                    onTap: (){
                      showModalBottomSheet(
                          context: context,
                          builder: (BuildContext context){
                            return Container(
                                padding: EdgeInsets.all(15),
                                width: double.infinity,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('Bc'),
                                    SizedBox(height:15,),
                                    ListTile(
                                      title: Text('8.8'),
                                      onTap: (){},
                                    ),
                                    ListTile(
                                      title: Text('8.4'),
                                      onTap: (){},
                                    ),
                                  ],
                                )
                            );
                          }
                      );
                    },
                  ),
                  InkWell(
                    child: Container(
                      width: 130,
                      height: 40,
                      decoration:const BoxDecoration(
                          border: Border(
                            left: BorderSide(color: Colors.black26,width: 1),
                            right: BorderSide(color: Colors.black26,width: 1),
                            top: BorderSide(color: Colors.black26,width: 1),
                            bottom: BorderSide(color: Colors.black26,width: 1),
                          )
                      ),
                      child:const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('Seçim edin'),
                      ),
                    ),
                    onTap: (){},
                  ),
                  InkWell(
                    child: Container(
                      width: 70,
                      height: 40,
                      decoration:const BoxDecoration(
                          border: Border(
                            left: BorderSide(color: Colors.black26,width: 1),
                            right: BorderSide(color: Colors.black26,width: 1),
                            top: BorderSide(color: Colors.black26,width: 1),
                            bottom: BorderSide(color: Colors.black26,width: 1),
                          )
                      ),
                      child:const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('1'),
                      ),
                    ),
                    onTap: (){},
                  ),
                ],
              ),
            ),

            // QIYMET VE SEBET
            SizedBox(height:35),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Text('32.00 Azn',style: TextStyle(
                      color:colorHome,
                      fontWeight: FontWeight.bold,
                      fontSize: 24
                  ),),
                  ElevatedButton(
                    onPressed: (){
                      showDialog(
                          context: context,
                          builder: (BuildContext index){
                            return AlertDialog(
                              backgroundColor: Colors.white,
                              title: Text('Alış-veriş etmək üçün şəxsi hesabınıza giriş edin',textAlign: TextAlign.center,
                              style: TextStyle(color:Colors.black),),
                              actions: [
                                TextButton(onPressed: (){Navigator.pop(context);}, child: Text('İmtina',style: TextStyle(color:Colors.redAccent),)),
                                TextButton(onPressed: (){
                                  Navigator.pop(context);
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
                                }, child: Text('Giriş et',style: TextStyle(color:Colors.black),)),
                              ],
                            );
                          }
                      );
                    },
                    child: Row(
                      children: [
                        Icon(Icons.shopping_cart,color: Colors.white,),
                        Text('Sebete at',style: TextStyle(color: Colors.white),)
                      ],
                    ),
                    style: ElevatedButton.styleFrom(
                      shape:RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                      backgroundColor: Colors.redAccent,

                    ),
                  )
                ],
              ),
            ),
            // Product About
            SizedBox(height:20,),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Container(
                child: Text('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
              ),
            ),
            const SizedBox(height:15,),
            const Divider(height: 1,color:Colors.black12),
            const SizedBox(height: 15,),
            const SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    child: Image.asset('assets/facebook-app-symbol.png',width: 30,color: Colors.blue,),
                  ),
                  InkWell(
                    child: Image.asset('assets/instagram.png',width: 30,),
                  ),
                  InkWell(
                    child: Image.asset('assets/youtube.png',width: 30,),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 35),
          ],
        ),
      ),
    );
  }
}

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/modal/product_details.dart';
import 'package:linzaplanet/screens/ShoppingCard.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:insta_image_viewer/insta_image_viewer.dart';

import 'LoginScreen.dart';

class ProductInfo extends StatefulWidget {
  String seflink;
  ProductInfo({super.key, required this.seflink});


  @override
  State<ProductInfo> createState() => _ProductInfoState();
}

class _ProductInfoState extends State<ProductInfo> {
  WebViewController? _webViewController;
  bool isLoading=true;
  int count = 0;
  var _response;

  bool isVisible = false;



  var querySelectLeft = 'Seçim edin';
  var querySelectorRight = 'Seçim edin';
  var bc_left = '8.8';
  var bc_right = '8.8';
  var quantity = '1';
  List<String> number_cyl=[
    '10',
    '20',
    '30',
    '40',
    '50',
    '60',
    '70',
    '80',
    '90',
    '100',
    '110',
    '120',
    '130',
    '140',
    '150',
    '160',
    '170',
    '180',
  ];
  List<String> astigmat = [
    '-2,25',
    '-1,75',
    '-1,25',
    '-0,25'
  ];
  String items_righ_cyl='Seç';
  String items_left_cyl='Seç';
  String left_color= 'Seç';
  String right_color = 'Seç';
  String left_cyl = 'Seç';
  String right_cyl = 'Seç';
  int selectedToricIndex = 1;

  final itemsOne = ['1','2','3','4'];
  final itemsTwo = ['1','2','3','4'];
  int indexOne = 0;
  int indexTwo = 0;

  late List for_left_eye;
  late List for_right_eye;
  late List colors_left;
  late List colors_right;

  Future getProductDetail() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/details/${widget.seflink}'));
    if(response.statusCode == 200){
      var result = productDetailsFromJson(response.body);
      setState(() {
        count = result.length;
        _response = result;

        colors_left = result[0].colorlist;
        colors_right = result[0].colorlist;
        for_left_eye = result[0].numberlist;
        for_right_eye = result[0].numberlist;
      });
      return true;
    }else{
      throw Exception('Bir xeta bas verdi');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getProductDetail();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Image.asset('assets/logo_my.png',width: 170,),
        actions: [
          IconButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>const ShoppingCard()));
              },
              icon: const Icon(Icons.shopping_cart)
          )
        ],
      ),
      body:count !=0 ? ListView.builder(
        itemCount: count,
          itemBuilder: (_,index){
            return Column(
              children: [
                InstaImageViewer(
                    child: Image.network('${_response[index].proImage}'),
                ),
                Text('${_response[index].proName}',style:const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.indigo
                ),),
                const SizedBox(height:15,),
                const Divider(height: 1,color:Colors.black12),
                const SizedBox(height: 15,),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0,right: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.question_answer_outlined,color: Colors.greenAccent,),
                          SizedBox(width:5,),
                          Text('Göz nömrələriniz fərqlidir?')
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color: isVisible == true ? Colors.greenAccent : const Color(0xc0eeeeee)
                            ),
                            child: TextButton(
                              onPressed: (){
                                setState(() {
                                  isVisible = true;
                                });
                              },
                              child: Text('Bəli',style: TextStyle(color:isVisible == true ? Colors.white : Colors.black45),),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                                color: isVisible == true ? const Color(0xc0eeeeee):Colors.greenAccent
                            ),
                            child: TextButton(
                              onPressed: (){
                                setState(() {
                                  isVisible = false;
                                });
                              },
                              child: Text('Xeyr',style: TextStyle(color:isVisible == true ? Colors.black45:Colors.white),),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(height:15,),
                const Divider(height: 1,color:Colors.black12),
                // nomrelerin duzulmesi
                const SizedBox(height:15),
                Padding(
                  padding: const EdgeInsets.only(left:15,right: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        children: [
                          const Text('Bc',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height:10),
                          InkWell(
                            child: Container(
                              width: _response[index].typeLens=='rengli-linzalar' || _response[index].typeLens=='astiqmat-linzalar' ? 40:80,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(bc_left),
                              ),
                            ),
                            onTap: (){
                              showModalBottomSheet(
                                  context: context,
                                  builder: (BuildContext context){
                                    return Container(
                                        padding: const EdgeInsets.all(15),
                                        width: double.infinity,
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Text('Bc'),
                                            const SizedBox(height:15,),
                                            ListTile(
                                              title: const Text('8.8'),
                                              onTap: (){
                                                setState(() {
                                                  Navigator.pop(context);
                                                  bc_left = '8.8';
                                                });
                                              },
                                            ),
                                            ListTile(
                                              title: const Text('8.4'),
                                              onTap: (){
                                                setState(() {
                                                  Navigator.pop(context);
                                                  bc_left = '8.4';
                                                });
                                              },
                                            ),
                                          ],
                                        )
                                    );
                                  }
                              );
                            },
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Sph(Pwr)',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height:10),
                          InkWell(
                            child: Container(
                              width: _response[index].typeLens=='rengli-linzalar' ? 130: _response[index].typeLens=='astiqmat-linzalar' ? 80:150,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text('${querySelectLeft}'),
                              ),
                            ),
                            onTap: (){
                              showModalBottomSheet(
                                backgroundColor:Colors.white,
                                  context: context,
                                  builder: (BuildContext context){
                                    return Container(
                                        padding: const EdgeInsets.all(15),
                                        width: double.infinity,
                                        child: Column(
                                          children: [
                                            Container(
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  const Text('Sph(Pwr)',style: TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                    fontSize: 17
                                                  ),),
                                                  TextButton(
                                                    onPressed: (){
                                                      Navigator.pop(context);
                                                    },
                                                    child:const Text('Bağla',style: TextStyle(
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 17,
                                                        color: Colors.lightBlue
                                                    ),),
                                                  ),
                                                ],

                                              ),
                                            ),
                                            Expanded(
                                              child: ListView.builder(
                                                itemCount: for_left_eye.length,
                                                  itemBuilder: (_,index){
                                                    return ListTile(
                                                      title:Text(for_left_eye[index]),
                                                      onTap: (){
                                                        setState(() {
                                                          Navigator.pop(context);
                                                          querySelectLeft = for_left_eye[index];
                                                        });
                                                      },
                                                    );
                                                  }
                                              ),
                                            ),
                                          ],
                                        ),
                                    );
                                  }
                              );
                            },
                          ),
                        ],
                      ),
                      if(_response[index].typeLens=='rengli-linzalar')Column(
                        children: [
                          const Text('Color',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height: 10),
                          InkWell(
                            child: Container(
                              width: 130,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text('${left_color}'),
                              ),
                            ),
                            onTap: (){
                              showCupertinoModalPopup(
                                context: context,
                                builder: (context) => CupertinoActionSheet(
                                  actions: [
                                    Row(
                                      children: [
                                        TextButton(
                                            onPressed: (){Navigator.pop(context);},
                                            child: Text('Bağla')
                                        ),
                                      ],
                                    ),

                                    Container(
                                      margin: EdgeInsets.only(top: 1,bottom: 20),
                                      child: SizedBox(
                                        height:100,
                                        child: CupertinoPicker(
                                          itemExtent:55,
                                          children: <Widget>[
                                            for(var i in colors_left) Center(
                                              child: Text(i.toString()),
                                            ),
                                          ],
                                          onSelectedItemChanged: (int value){
                                            setState(() {
                                              left_color = colors_left[value];
                                            });
                                          },
                                        ),
                                      ),

                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      if(_response[index].typeLens=='astiqmat-linzalar')Column(
                        children: [
                          const Text('Cyl',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height: 10),
                          InkWell(
                            child: Container(
                              width:_response[index].typeLens=='astiqmat-linzalar'?80: 130,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text('${left_cyl}'),
                              ),
                            ),
                            onTap: (){
                              showCupertinoModalPopup(
                                context: context,
                                builder: (context) => CupertinoActionSheet(
                                  actions: [
                                    Row(
                                      children: [
                                        TextButton(
                                            onPressed: (){Navigator.pop(context);},
                                            child: Text('Bağla')
                                        ),
                                      ],
                                    ),

                                    Container(
                                      margin: EdgeInsets.only(top: 1,bottom: 20),
                                      child: SizedBox(
                                        height:100,
                                        child: CupertinoPicker(
                                          itemExtent:55,
                                          children: <Widget>[
                                            for(var i in number_cyl) Center(
                                              child: Text(i.toString()),
                                            ),
                                          ],
                                          onSelectedItemChanged: (int value){
                                            setState(() {
                                              left_cyl = number_cyl[value];
                                            });
                                          },
                                        ),
                                      ),

                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      if(_response[index].typeLens=='astiqmat-linzalar')Column(
                        children: [
                          const Text('Ax',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height: 10),
                          InkWell(
                            child: Container(
                              width: _response[index].typeLens=='astiqmat-linzalar'?80:130,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text('${items_left_cyl}'),
                              ),
                            ),
                            onTap: (){
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context)=>CupertinoActionSheet(
                                    title: Text('Cyl(Ax)',textAlign: TextAlign.left,style: TextStyle(
                                        fontSize: 16
                                    ),),
                                    actions: [
                                      SizedBox(
                                        height: 130,
                                        child: CupertinoPicker(
                                          itemExtent:45,
                                          children: <Widget>[
                                            for(var i in astigmat) Center(
                                              child: Text(i.toString()),
                                            ),
                                          ],
                                          onSelectedItemChanged: (int value){
                                            setState(() {
                                              items_left_cyl = astigmat[value];
                                            });
                                          },
                                        ),
                                      )
                                    ],
                                  )
                              );
                            },
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Eded',style: TextStyle(
                              color: colorHome,
                              fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height:10),
                          InkWell(
                            child: Container(
                              width: _response[index].typeLens=='rengli-linzalar' || _response[index].typeLens=='astiqmat-linzalar'?40:80,
                              height: 40,
                              decoration:const BoxDecoration(
                                  border: Border(
                                    left: BorderSide(color: Colors.black26,width: 1),
                                    right: BorderSide(color: Colors.black26,width: 1),
                                    top: BorderSide(color: Colors.black26,width: 1),
                                    bottom: BorderSide(color: Colors.black26,width: 1),
                                  )
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(itemsOne[indexOne]),
                              ),
                            ),
                            onTap: (){
                              showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => CupertinoActionSheet(
                                    actions: [
                                       Row(
                                          children: [
                                            TextButton(
                                                onPressed: (){Navigator.pop(context);},
                                                child: Text('Bağla')
                                            ),
                                          ],
                                        ),

                                      Container(
                                        margin: EdgeInsets.only(top: 1,bottom: 20),
                                        child: SizedBox(
                                          height:100,
                                          child: CupertinoPicker(
                                            itemExtent: 55,
                                            onSelectedItemChanged: (index){
                                              setState(() {
                                                indexOne = index;
                                              });
                                            },
                                            children: itemsOne.map((itemsOne) => Center(
                                              child: Text(itemsOne[index]),
                                            )).toList(),
                                          ),
                                        ),

                                      ),
                                    ],
                                  ),
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if(isVisible)
                  // TODO:ikinci goz formunu acmaq ucun
                  Padding(
                    padding: const EdgeInsets.only(left:15,right: 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width: _response[index].typeLens=='rengli-linzalar' || _response[index].typeLens=='astiqmat-linzalar' ? 40:80,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(bc_right),
                                ),
                              ),
                              onTap: (){
                                showModalBottomSheet(
                                    context: context,
                                    builder: (BuildContext context){
                                      return Container(
                                          padding: const EdgeInsets.all(15),
                                          width: double.infinity,
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              const Text('Bc'),
                                              const SizedBox(height:15,),
                                              ListTile(
                                                title: const Text('8.8'),
                                                onTap: (){
                                                  setState(() {
                                                    Navigator.pop(context);
                                                    bc_right = '8.8';
                                                  });
                                                },
                                              ),
                                              ListTile(
                                                title: const Text('8.4'),
                                                onTap: (){
                                                  setState(() {
                                                    Navigator.pop(context);
                                                    bc_right = '8.4';
                                                  });
                                                },
                                              ),
                                            ],
                                          )
                                      );
                                    }
                                );
                              },
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width: _response[index].typeLens=='rengli-linzalar' ? 130: _response[index].typeLens=='astiqmat-linzalar' ? 80:150,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text('${querySelectorRight}'),
                                ),
                              ),
                              onTap: (){
                                showModalBottomSheet(
                                    backgroundColor:Colors.white,
                                    context: context,
                                    builder: (BuildContext context){
                                      return Container(
                                        padding: const EdgeInsets.all(15),
                                        width: double.infinity,
                                        child: Column(
                                          children: [
                                            Container(
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  const Text('Sph(Pwr)',style: TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 17
                                                  ),),
                                                  TextButton(
                                                    onPressed: (){
                                                      Navigator.pop(context);
                                                    },
                                                    child:const Text('Bağla',style: TextStyle(
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 17,
                                                        color: Colors.lightBlue
                                                    ),),
                                                  ),
                                                ],

                                              ),
                                            ),
                                            Expanded(
                                              child: ListView.builder(
                                                  itemCount: for_right_eye.length,
                                                  itemBuilder: (_,index){
                                                    return ListTile(
                                                      title:Text(for_right_eye[index]),
                                                      onTap: (){
                                                        setState(() {
                                                          Navigator.pop(context);
                                                          querySelectorRight = for_right_eye[index];
                                                        });
                                                      },
                                                    );
                                                  }
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    }
                                );
                              },
                            ),
                          ],
                        ),
                        if(_response[index].typeLens=='rengli-linzalar')Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width: 130,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('${right_color}'),
                                ),
                              ),
                              onTap: (){
                                showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => CupertinoActionSheet(
                                    actions: [
                                      Row(
                                        children: [
                                          TextButton(
                                              onPressed: (){Navigator.pop(context);},
                                              child: Text('Bağla')
                                          ),
                                        ],
                                      ),

                                      Container(
                                        margin: EdgeInsets.only(top: 1,bottom: 20),
                                        child: SizedBox(
                                          height:100,
                                          child: CupertinoPicker(
                                            itemExtent:55,
                                            children: <Widget>[
                                              for(var i in colors_right) Center(
                                                child: Text(i.toString()),
                                              ),
                                            ],
                                            onSelectedItemChanged: (int value){
                                              setState(() {
                                                right_color = colors_right[value];
                                              });
                                            },
                                          ),
                                        ),

                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                        if(_response[index].typeLens=='astiqmat-linzalar')Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width:_response[index].typeLens=='astiqmat-linzalar'?80: 130,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('${right_cyl}'),
                                ),
                              ),
                              onTap: (){
                                showCupertinoModalPopup(
                                  context: context,
                                  builder: (context) => CupertinoActionSheet(
                                    actions: [
                                      Row(
                                        children: [
                                          TextButton(
                                              onPressed: (){Navigator.pop(context);},
                                              child: Text('Bağla')
                                          ),
                                        ],
                                      ),

                                      Container(
                                        margin: EdgeInsets.only(top: 1,bottom: 20),
                                        child: SizedBox(
                                          height:100,
                                          child: CupertinoPicker(
                                            itemExtent:55,
                                            children: <Widget>[
                                              for(var i in number_cyl) Center(
                                                child: Text(i.toString()),
                                              ),
                                            ],
                                            onSelectedItemChanged: (int value){
                                              setState(() {
                                                right_cyl = number_cyl[value];
                                              });
                                            },
                                          ),
                                        ),

                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                        if(_response[index].typeLens=='astiqmat-linzalar')Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width: _response[index].typeLens=='astiqmat-linzalar'?80:130,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text(items_righ_cyl),
                                ),
                              ),
                              onTap: (){
                                showCupertinoModalPopup(
                                    context: context,
                                    builder: (context)=>CupertinoActionSheet(
                                      title: Text('Cyl(Ax)',textAlign: TextAlign.left,style: TextStyle(
                                        fontSize: 16
                                      ),),
                                      actions: [
                                        SizedBox(
                                          height: 130,
                                          child: CupertinoPicker(
                                            itemExtent:45,
                                            children: <Widget>[
                                              for(var i in astigmat) Center(
                                                child: Text(i.toString()),
                                              ),
                                            ],
                                            onSelectedItemChanged: (int value){
                                              setState(() {
                                                items_righ_cyl = astigmat[value];
                                              });
                                            },
                                          ),
                                        )
                                      ],
                                    )
                                );
                              },
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            const SizedBox(height: 15),
                            InkWell(
                              child: Container(
                                width: _response[index].typeLens=='rengli-linzalar' || _response[index].typeLens=='astiqmat-linzalar'?40:80,
                                height: 40,
                                decoration:const BoxDecoration(
                                    border: Border(
                                      left: BorderSide(color: Colors.black26,width: 1),
                                      right: BorderSide(color: Colors.black26,width: 1),
                                      top: BorderSide(color: Colors.black26,width: 1),
                                      bottom: BorderSide(color: Colors.black26,width: 1),
                                    )
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(itemsTwo[indexTwo]),
                                ),
                              ),
                              onTap: (){
                                showCupertinoModalPopup(
                                    context: context,
                                    builder: (context) => CupertinoActionSheet(
                                      actions: [
                                        Row(
                                          children: [
                                            TextButton(
                                                onPressed: (){Navigator.pop(context);},
                                                child: Text('Bağla')
                                            ),
                                          ],
                                        ),
                                        Container(
                                          height: 100,
                                          margin: EdgeInsets.only(top: 1,bottom: 10),
                                          child: CupertinoPicker(
                                            itemExtent: 55,
                                            onSelectedItemChanged: (index){
                                              setState(() {
                                                this.indexTwo = index;
                                                final item = index;
                                              });
                                            },
                                            children: itemsTwo.map((itemsTwo)=>Center(
                                              child: Text(itemsTwo[index]),
                                            ),).toList(),
                                          ),

                                        ),
                                      ],
                                    )
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                // TODO:ikinci goz formu baglanir
                // QIYMET VE SEBET
                const SizedBox(height:35),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('${_response[index].proPrice} Azn',style:const TextStyle(
                          color:colorHome,
                          fontWeight: FontWeight.bold,
                          fontSize: 24
                      ),),
                      SizedBox(
                        height: 50,
                        width: 180,
                        child: ElevatedButton(
                          onPressed: (){
                            showCupertinoDialog(
                                context: context,
                                builder: (context)=>Theme(
                                    data: ThemeData(
                                        dialogBackgroundColor: Colors.white,
                                        dialogTheme: const DialogTheme(backgroundColor: Colors.black)),
                                    child: CupertinoAlertDialog(
                                      title: const Text('Bildiriş!'),
                                      content: const Text('Alış-veriş etmək üçün şəxsi hesabınıza giriş edin',textAlign: TextAlign.center,
                                        style: TextStyle(color:Colors.black),),
                                      actions: [
                                        CupertinoDialogAction(
                                          onPressed: (){
                                            Navigator.pop(context);
                                          },
                                          isDefaultAction: true,
                                          child: const Text('İmtina',style:TextStyle(color:Colors.redAccent)),
                                        ),
                                        CupertinoDialogAction(
                                          child: const Text('Giriş'),
                                          onPressed: (){
                                            Navigator.pop(context);
                                            Navigator.push(context, MaterialPageRoute(builder: (context)=>const LoginScreen()));
                                          },
                                        ),
                                      ],
                                    )
                                )
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            shadowColor: Colors.redAccent[400],
                            elevation: 8,
                            shape:RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: Colors.redAccent[400],
                          ),
                          child:const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Icon(Icons.shopping_cart,color: Colors.white,),
                              Text('Səbətə at',style: TextStyle(color: Colors.white,fontSize:17),)
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                // Product About
                const SizedBox(height:20,),
                Container(
                  padding: const EdgeInsets.only(top: 20,bottom: 20,left: 15),
                  width: double.infinity,
                  color: const Color(0xFFDADADA),
                  child: const Text('Məhsul haqqında',style:TextStyle(fontSize: 18)),
                ),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: Container(
                    child: Text('${_response[index].proDetail}',style: const TextStyle(fontSize:16),textAlign: TextAlign.justify,),
                  ),
                ),
                const SizedBox(height:15,),
                const Divider(height: 1,color:Colors.black12),
                Column(
                  children: [
                    Container(
                      height: 70,
                      color: colorHome,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/courier.png',color:Colors.white,width:50,),
                          const SizedBox(width: 20,),
                          const Text('Güvənli çatdırılma',style: TextStyle(
                              fontSize: 22,
                              color:Colors.white
                          ),),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      height: 70,
                      color: Colors.blueAccent,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/best-product.png',color:Colors.white,width:50,),
                          const SizedBox(width: 20,),
                          const Text('Orijinal məhsul',style: TextStyle(
                              fontSize: 22,
                              color:Colors.white
                          ),),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      height: 70,
                      color: Colors.green,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/credit-card.png',color:Colors.white,width:50,),
                          const SizedBox(width: 20,),
                          const Text('Hissə-Hissə ödə',style: TextStyle(
                              fontSize: 22,
                              color:Colors.white
                          ),),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      height: 70,
                      color: Colors.deepPurple,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/money.png',color:Colors.white,width:50,),
                          const SizedBox(width: 20,),
                          const Text('Qapıda ödəmə',style: TextStyle(
                              fontSize: 22,
                              color:Colors.white
                          ),),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15,),

                const SizedBox(height: 15),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      InkWell(
                        child: Image.asset('assets/facebook-app-symbol.png',width: 30,color: Colors.blue,),
                      ),
                      InkWell(
                        child: Image.asset('assets/instagram.png',width: 30,),
                      ),
                      InkWell(
                        child: Image.asset('assets/youtube.png',width: 30,),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 35),
              ],
            );
          }
      ):const Center(child: CircularProgressIndicator(),),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:linzaplanet/component/color.dart';

import '../modal/MyRequests.dart';

class ShoppingCard extends StatefulWidget {
  const ShoppingCard({super.key});

  @override
  State<ShoppingCard> createState() => _ShoppingCardState();
}

class _ShoppingCardState extends State<ShoppingCard> {

  int? _count;
  var listValue;




@override
  void initState() {
    // TODO: implement initState
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Colors.white,
        title: Image.asset('assets/logo_my.png',width: 170,),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 12.0),
            child: Text('Səbət'),
          )
        ],
      ),
      body: ListView.builder(
        itemCount: 2,
          itemBuilder: (_, index){
            return Container(
              padding: EdgeInsets.only(left: 7, right: 7),
              child: Card(
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: EdgeInsets.only(left:7,top: 10,bottom: 10),
                          child: Column(
                            children: [
                              Text('13 Noyabr 2023'),
                              SizedBox(height:7,),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: RichText(
                                  text:const TextSpan(
                                    text: 'Toplam:',
                                    style: TextStyle(color:Colors.black54,
                                    fontWeight: FontWeight.w600),
                                    children: [
                                      TextSpan(text: '28.0 Azn', style: TextStyle(fontWeight: FontWeight.bold,color: colorHome)),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        TextButton(
                            onPressed: (){},
                            child: Text('Etrafli')
                        )
                      ],
                    ),
                    Divider(height:1,color: Colors.black26,),
                    SizedBox(height: 5,),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Tehvil verildi'),
                          SizedBox(height: 10),
                          Container(
                            height: 80,
                            width: 80,
                            color: colorHome,
                          ),
                          SizedBox(height: 20),
                          Text('Bizi secdiyiniz ucun tesekkurler',
                          style:TextStyle(
                            fontSize: 13
                          )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
      )
    );
  }
}

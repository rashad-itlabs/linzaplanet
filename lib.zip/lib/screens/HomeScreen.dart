import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:linzaplanet/main.dart';
import 'package:linzaplanet/modal/for_colors.dart';
import 'package:linzaplanet/modal/for_white_lens.dart';
import 'package:linzaplanet/screens/ProductInfo.dart';
import 'package:linzaplanet/screens/SearchProductDetail.dart';
import 'package:linzaplanet/screens/sidebar.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:http/http.dart' as http;
import 'package:scroll_snap_list/scroll_snap_list.dart';
import 'package:snapping_page_scroll/snapping_page_scroll.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Classes/FilterList.dart';
import '../component/color.dart';
import '../modal/forFilter.dart';



class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _webprogress = 0;
  WebViewController? _webViewController;
  String price = '';
  bool isLoading=true;
  late String finalEmail;


  int? count_colors;
  int count_white_colors = 0;
  int count_monthly = 0;
  var colorsList;
  var whiteLensList;
  var listMonthly;

  var listFilter;

  Future _getShared() async{
    final SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var sessionEmail = sharedPreferences.getString('token');
    setState(() {
      finalEmail = sessionEmail!;
    });
  }

  // For colors Api
  Future  callColorList() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/list_colors'));
    if(response.statusCode==200){
      var result = lensColorsFromJson(response.body);
      setState(() {
        count_colors = result.length;
        colorsList = result;
      });
      return true;
    }else{
      throw Exception('Bir xeta bas verdi');
    }
  }

  Future  filterList() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/forSearch'));
    if(response.statusCode==200){
      var result = filterArrayFromJson(response.body);
      setState(() {
        listFilter = result;
      });
      return true;
    }else{
      throw Exception('Bir xeta bas verdi');
    }
  }

  // white lenses

  Future  callWhiteColorList() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/white_colors'));
    if(response.statusCode==200){
      var result = whiteColorsFromJson(response.body);
      setState(() {
        count_white_colors = result.length;
        whiteLensList = result;
      });
    }else{
      throw Exception('Bir xeta bas verdi');
    }
  }

  Future  monthlyLenses() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/monthly_lenses'));
    if(response.statusCode==200){
      var result = whiteColorsFromJson(response.body);
      setState(() {
        count_monthly = result.length;
        listMonthly = result;
      });
    }else{
      throw Exception('Bir xeta bas verdi');
    }
  }


  final scrollController = ScrollController();
  int _currentIndex = 0;
  final PageController _controller = PageController();
  final PageController _controller_2 = PageController(
      viewportFraction: 1,
      keepPage: true,
  );
  final PageController _controller_3 = PageController(
    viewportFraction: 0.75,

  );
  final PageController _controller_4 = PageController();


  List imagelist = [
    {'id':1,"image_path":"assets/image_1.jpeg"},
    {'id':2,"image_path":"assets/image_2.webp"},
  ];
  final CarouselController carouselController = CarouselController();
  int currentIndex = 0;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    callColorList();
    callWhiteColorList();
    monthlyLenses();
    _getShared();

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: const Sidebar(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Image.asset('assets/logo_my.png',width: 170,),
        actions: [
          IconButton(
              onPressed: (){},
              icon: const Icon(Icons.shopping_cart)
          ),
          IconButton(
              onPressed: (){
                showSearch(
                    context: context,
                    delegate: MySearchDelegate()
                );
              },
              icon: const Icon(Icons.search)
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Column(
              children: [
                Stack(
                  children: [
                    InkWell(
                      onTap: (){},
                      child: CarouselSlider(
                        items: imagelist.map(
                                (item)=>Image.asset(
                              item['image_path'],
                              fit: BoxFit.cover,
                              width: double.infinity,
                            )
                        ).toList(),
                        options: CarouselOptions(
                            scrollPhysics: const BouncingScrollPhysics(),
                            autoPlay: true,
                            aspectRatio: 2,
                            viewportFraction: 1,
                            onPageChanged: (index, reason){
                              setState(() {
                                currentIndex = index;
                              });
                            }
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      left:0,
                      right: 0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: imagelist.asMap().entries.map((entry) =>
                            Container(
                              width: 15,
                              height: 15,
                              margin: const EdgeInsets.symmetric(horizontal: 3.0),
                              decoration: BoxDecoration(
                                  border:const Border(
                                    left: BorderSide(color:Colors.white,width: 1),
                                    right: BorderSide(color:Colors.white,width: 1),
                                    top: BorderSide(color:Colors.white,width: 1),
                                    bottom: BorderSide(color:Colors.white,width: 1),
                                  ),
                                  borderRadius: BorderRadius.circular(50),
                                  color: currentIndex ==entry.key
                                      ? Colors.white
                                      : Colors.transparent
                              ),
                            ),
                        ).toList(),
                      ),
                    )
                  ],

                ),
              ],
            ),
            const SizedBox(height: 20),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Rəngli Linzalar',
                textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                Icon(Icons.expand_circle_down,color:colorHome,)
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              height: 295,
              child: Stack(
                children: [
                  ListView.builder(
                      controller: _controller,
                      itemCount: count_colors,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index){
                        return Container(
                          margin: const EdgeInsets.only(right: 16),
                          height: 160,
                          width: 175,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border:const Border(
                              left: BorderSide(color: Colors.black12,width: 1),
                              right: BorderSide(color: Colors.black12,width: 1),
                              top: BorderSide(color: Colors.black12,width: 1),
                              bottom: BorderSide(color: Colors.black12,width: 1),
                            ),
                            color: Colors.white,
                          ),
                          child:count_colors != null ? Column(
                            children: [
                              Image.network('${colorsList[index].proImage}',width: 140,height: 140,),
                              const SizedBox(height:11),
                              Padding(
                                padding:const EdgeInsets.all(8.0),
                                child: Text('${colorsList[index].proName}',textAlign: TextAlign.center,style:const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                )),
                              ),
                              const SizedBox(height:10),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(left:10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                     Text('${colorsList[index].proPrice} Azn',textAlign: TextAlign.center,style:const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    )),
                                    IconButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink:colorsList[index].seflink)));
                                        },
                                        icon: const Icon(Icons.arrow_forward,color: colorHome,)
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height:5),
                            ],
                          ):const Stack(),
                        );
                      }
                  ),
                  Positioned(
                    top:0,
                    left:-15,
                    right: -10,
                    bottom: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(onPressed: (){
                          setState(() {
                            //_controller.jumpTo( _currentIndex-1);
                            _currentIndex--;
                            _controller.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_back_ios_new,color:Colors.black12,),),
                        IconButton(onPressed: (){
                          setState(() {
                            _currentIndex++;
                            _controller.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_forward_ios,color: Colors.black12,),),
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 10),

            //Seffaf linzalar
            const SizedBox(height: 20),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Şəffaf Linzalar',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 18
                  ),
                ),
                Icon(Icons.expand_circle_down,color:colorHome,)
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              height: 300,
              child: Stack(
                children: [
                  ListView.builder(
                      controller: _controller_2,
                      itemCount: count_white_colors,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index){
                        return Container(
                          margin: const EdgeInsets.only(right: 16),
                          height: 150,
                          width: 175,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border:const Border(
                              left: BorderSide(color: Colors.black12,width: 1),
                              right: BorderSide(color: Colors.black12,width: 1),
                              top: BorderSide(color: Colors.black12,width: 1),
                              bottom: BorderSide(color: Colors.black12,width: 1),
                            ),
                            color: Colors.white,
                          ),
                          child:count_white_colors !=null ? Column(
                            children: [
                              const SizedBox(height:20),
                              Image.network('${whiteLensList[index].proImage}',width: 140,height: 110,),
                              const SizedBox(height:15),
                              Padding(
                                padding:const EdgeInsets.all(8.0),
                                child: Text('${whiteLensList[index].proName}',textAlign: TextAlign.center,style:const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                )),
                              ),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(left:10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('${whiteLensList[index].proPrice} Azn',textAlign: TextAlign.center,style:const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    )),
                                    IconButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink:whiteLensList[index].seflink)));
                                        },
                                        icon: const Icon(Icons.arrow_forward,color: colorHome,)
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height:5),
                            ],
                          ):const Stack(),
                        );
                      }
                  ),
                  Positioned(
                    top:0,
                    left:-15,
                    right: -10,
                    bottom: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(onPressed: (){
                          setState(() {
                            _currentIndex--;
                            _controller_2.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_back_ios_new,color:Colors.black12,),),
                        IconButton(onPressed: (){
                          setState(() {
                            _currentIndex++;
                            _controller_2.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
                          });
                        }, icon: const Icon(Icons.arrow_forward_ios,color: Colors.black12,),),
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 10),

            // AYLIQ LINZALAR
            const SizedBox(height: 20),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Aylıq Linzalar',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 18
                  ),
                ),
                Icon(Icons.expand_circle_down,color:colorHome,)
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              height: 340,
              child: Stack(
                children: [
                  ListView.builder(
                      controller: _controller_3,
                      itemCount: count_monthly,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index){
                        return Container(
                          margin: const EdgeInsets.only(right: 16),
                          height: 150,
                          width: 175,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border:const Border(
                              left: BorderSide(color: Colors.black12,width: 1),
                              right: BorderSide(color: Colors.black12,width: 1),
                              top: BorderSide(color: Colors.black12,width: 1),
                              bottom: BorderSide(color: Colors.black12,width: 1),
                            ),
                            color: Colors.white,
                          ),
                          child: Column(
                            children: [
                              const SizedBox(height:20),
                              Image.network('${listMonthly[index].proImage}',width: 140,height: 140,),
                              const SizedBox(height:15),
                              Padding(
                                padding:const EdgeInsets.all(8.0),
                                child: Text('${listMonthly[index].proName}',textAlign: TextAlign.center,style:const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                )),
                              ),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(left:10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('${listMonthly[index].proPrice} Azn',textAlign: TextAlign.center,style:const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    )),
                                    IconButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink:listMonthly[index].seflink)));
                                        },
                                        icon: const Icon(Icons.arrow_forward,color: colorHome,)
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height:5),
                            ],
                          ),
                        );
                      }
                  ),
                  Positioned(
                    top:0,
                    left:-15,
                    right: -10,
                    bottom: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(onPressed: (){
                          setState(() {
                            //_controller.jumpTo( _currentIndex-1);
                            _currentIndex--;
                            _controller_3.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_back_ios_new,color:Colors.black12,),),
                        IconButton(onPressed: (){
                          setState(() {
                            _currentIndex++;
                            _controller_3.animateToPage(_currentIndex, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_forward_ios,color: Colors.black12,),),
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 10),

            //Asitgmat linzalar
            const SizedBox(height: 20),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Astiqmat Linzalar',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 18
                  ),
                ),
                Icon(Icons.expand_circle_down,color:colorHome,)
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              height: 285,
              child: Stack(
                children: [
                  ListView.builder(
                      controller: _controller_4,
                      itemCount: 5,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index){
                        return Container(
                          margin: const EdgeInsets.only(right: 16),
                          height: 150,
                          width: 175,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border:const Border(
                              left: BorderSide(color: Colors.black12,width: 1),
                              right: BorderSide(color: Colors.black12,width: 1),
                              top: BorderSide(color: Colors.black12,width: 1),
                              bottom: BorderSide(color: Colors.black12,width: 1),
                            ),
                            color: Colors.white,
                          ),
                          child: Column(
                            children: [
                              const SizedBox(height:20),
                              Image.network('https://linzaplanet.az/upload/flod_(2)1.jpg',width: 140,),
                              const SizedBox(height:15),
                              const Padding(
                                padding:EdgeInsets.all(8.0),
                                child: Text('FRESHLOOK ONEDAY',textAlign: TextAlign.center,style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                )),
                              ),
                              const SizedBox(height:10),
                              const Padding(
                                padding:  EdgeInsets.all(8.0),
                                child: Divider(height: 1,color: Colors.black12,),
                              ),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(left:10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('22.0 Azn',textAlign: TextAlign.center,style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    )),
                                    IconButton(
                                        onPressed: (){},
                                        icon: const Icon(Icons.arrow_forward,color: colorHome,)
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height:5),
                            ],
                          ),
                        );
                      }
                  ),
                  Positioned(
                    top:0,
                    left:-15,
                    right: -10,
                    bottom: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(onPressed: (){
                          setState(() {
                            //_controller.jumpTo( _currentIndex-1);
                            _controller_4.animateTo(_currentIndex-1, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_back_ios_new,color:Colors.black12,),),
                        IconButton(onPressed: (){
                          setState(() {
                            _controller_4.animateToPage(_currentIndex+1, duration: const Duration(milliseconds: 500), curve: Curves.ease);
                          });
                        }, icon: const Icon(Icons.arrow_forward_ios,color: Colors.black12,),),
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 10),

            //List
            Column(
              children: [
                Container(
                  height: 70,
                  color: colorHome,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/courier.png',color:Colors.white,width:50,),
                      const SizedBox(width: 20,),
                      const Text('Güvənli çatdırılma',style: TextStyle(
                        fontSize: 22,
                        color:Colors.white
                      ),),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  height: 70,
                  color: Colors.blueAccent,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/best-product.png',color:Colors.white,width:50,),
                      const SizedBox(width: 20,),
                      const Text('Orijinal məhsul',style: TextStyle(
                          fontSize: 22,
                          color:Colors.white
                      ),),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  height: 70,
                  color: Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/credit-card.png',color:Colors.white,width:50,),
                      const SizedBox(width: 20,),
                      const Text('Hissə-Hissə ödə',style: TextStyle(
                          fontSize: 22,
                          color:Colors.white
                      ),),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  height: 70,
                  color: Colors.deepPurple,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/money.png',color:Colors.white,width:50,),
                      const SizedBox(width: 20,),
                      const Text('Qapıda ödəmə',style: TextStyle(
                          fontSize: 22,
                          color:Colors.white
                      ),),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    child: Image.asset('assets/facebook-app-symbol.png',width: 30,color: Colors.blue,),
                  ),
                  InkWell(
                    child: Image.asset('assets/instagram.png',width: 30,),
                  ),
                  InkWell(
                    child: Image.asset('assets/youtube.png',width: 30,),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 15),
          ],
        ),
      ),
    );
  }
}
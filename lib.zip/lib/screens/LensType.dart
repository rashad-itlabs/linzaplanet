import 'package:flutter/material.dart';
import 'package:linzaplanet/categories/PageCategories.dart';
import 'package:linzaplanet/modal/lensType.dart';

import '../categories/Pages.dart';
import '../component/color.dart';
import 'package:http/http.dart' as http;

class LensType extends StatefulWidget {
  const LensType({super.key});

  @override
  State<LensType> createState() => _LensTypeState();
}

class _LensTypeState extends State<LensType> {

  int count = 0;
  var list;

  Future lenstype() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/lensType'));
    if(response.statusCode==200){
      var result = lensTypeFromJson(response.body);
      setState(() {
        count = result.length;
        list = result;
      });
      return true;
    }else{
      throw Exception('Fatal Error');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    lenstype();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body:count !=0 ? ListView.builder(
        itemCount: count,
          itemBuilder: (_, index){
            return ListTile(
              title: Text('${list[index].lensName}'),
              minLeadingWidth: 2,
              leading: Icon(Icons.arrow_forward_ios,size: 16,color:colorHome),
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>PageCategories(seflink:list[index].seflink)));
              },
            );
          }
      ):Center(child: CircularProgressIndicator(),),
    );
  }
}

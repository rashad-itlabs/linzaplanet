import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/main.dart';
import 'package:linzaplanet/screens/home.dart';
import 'package:linzaplanet/users/AboutApp.dart';
import 'package:linzaplanet/users/MyOrderPage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          children: [
              CircleAvatar(radius: 60,child:
               Image.asset('assets/user.png'),),
             const SizedBox(height: 10,),
             const Text('Rashad Aliyev',
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 19
              ),),
            const SizedBox(height:5,),
              Text('${sharedPreferences.getString('token')}',
              style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 13
              ),),
             const SizedBox(height:15,),
             const Divider(height: 1,),
             const SizedBox(height:15,),
            ListTile(
              title: const Text('Sifarişlərim'),
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>const MyOrder()));
              },
            ),
            ListTile(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>const AboutApp()));
              },
              title:const Text('Tətbiq haqqında'),
            ),
            ListTile(
              onTap: (){

              },
              title:const Text('Tənzimləmələr'),
            ),
            ListTile(
              onTap: (){
                sharedPreferences.clear();
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (BuildContext context) => Home()),
                        (Route<dynamic> route) => false);
              },
              title: Text('Etibarlı çıxış'),
            ),
          ],
        ),
      ),
    );
  }
}

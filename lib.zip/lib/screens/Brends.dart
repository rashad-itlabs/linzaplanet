import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:linzaplanet/categories/Pages.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:http/http.dart' as http;
import 'package:linzaplanet/modal/brends.dart';

class Brends extends StatefulWidget {
  const Brends({super.key});

  @override
  State<Brends> createState() => _BrendsState();
}

class _BrendsState extends State<Brends> {
  int count = 0;
  var list;

  Future getBrands() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/brends'));
    if(response.statusCode == 200){
      var result = brendsFromJson(response.body);
      setState(() {
        count = result.length;
        list = result;
      });
    }else{
      throw Exception('Fatal Error');
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getBrands();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: count !=0 ? ListView.builder(
        itemCount: count,
          itemBuilder:(_, index){
            return ListTile(
              title: Text('${list[index].brendName}'),
              minLeadingWidth: 2,
              leading: Icon(Icons.arrow_forward_ios,size: 16,color:colorHome),
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Pages(seflink: list[index].seflink, brand:list[index].brendName)));
              },
            );
          }
      ):Center(child: CircularProgressIndicator(),),
    );
  }
}

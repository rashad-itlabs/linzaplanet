import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/screens/Categories.dart';
import 'package:linzaplanet/screens/HeplScreen.dart';
import 'package:linzaplanet/screens/HomeScreen.dart';
import 'package:linzaplanet/screens/LoginScreen.dart';
import 'package:linzaplanet/screens/Profile.dart';
import 'package:linzaplanet/screens/sidebar.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';



class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  int _currentBottom = 0;
  String finalEmail = '';






  Future _getShared() async{
    final SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var sessionEmail = sharedPreferences.getString('token');
    setState(() {
      finalEmail = sessionEmail!;
    });
  }

  final tabs = [
    HomeScreen(),
    Categories(),
    HelpScreen(),
    LoginScreen(),
  ];

  final tabsLogin = [
    HomeScreen(),
    Categories(),
    HelpScreen(),
    Profile(),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getShared();
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:finalEmail!='' ? tabsLogin[_currentBottom]:tabs[_currentBottom],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentBottom,
        fixedColor: colorHome,
        //unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              icon: Image.asset('assets/icons/home.png',
                color: _currentBottom ==0 ?Colors.orange:Colors.grey,
                width: 28,
              ),
              label: 'Əsas',
          ),
          BottomNavigationBarItem(
              icon: Image.asset('assets/icons/category.png',
                color: _currentBottom ==1 ?Colors.orange:Colors.grey,
                width: 28,
              ),
              label: 'Kateqoriya',
          ),
          BottomNavigationBarItem(
              icon: Image.asset('assets/icons/question.png',
                color: _currentBottom ==2 ?Colors.orange:Colors.grey,
                width: 28,
              ),
              label: 'Kömək'
          ),
          BottomNavigationBarItem(
              icon:finalEmail !='' ? Image.asset('assets/icons/user.png',
                color: _currentBottom ==3 ?Colors.orange:Colors.grey,
                width: 28,
              ):
              Image.asset('assets/icons/person.png',
                color: _currentBottom == 3 ?Colors.orange:Colors.grey,
                width: 28,
              ),
              label: finalEmail !='' ? 'Profil':'Giriş'
          ),
        ],
        onTap: (index){
          setState(() {
            _currentBottom = index;
          });
        },
      ),
    );
  }
}

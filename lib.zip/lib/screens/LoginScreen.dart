import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/screens/ForgetPassword.dart';
import 'package:linzaplanet/screens/Profile.dart';
import 'package:linzaplanet/screens/Registration.dart';
import 'package:linzaplanet/screens/home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LogonScreenState();
}

class _LogonScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  var isObscureText;

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();

  Future login() async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    final url = Uri.parse('https://linzaplanet.az/api/signin');
    var response = await http.post(url,body: {
      'email':email.text,
      'password':password.text
    });
    var result = jsonDecode(response.body);
    if(result['messages']=='true'){
      EasyLoading.showSuccess(
          'Uğurlu giriş',maskType: EasyLoadingMaskType.custom);
      EasyLoading.dismiss();
      setState(() {
        sharedPreferences.setString('token', email.text);
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (BuildContext context) => const Home()),
                (Route<dynamic> route) => false);
      });
    }else{
      EasyLoading.showError(result['messages'],maskType: EasyLoadingMaskType.custom);
      EasyLoading.dismiss();
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isObscureText = true;


  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: false,
        title: const Text('Giriş'),
      ),
      body: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(10)
                    ),
                    child: const Icon(Icons.people,color: Colors.white,),
                  ),
                  const SizedBox(width: 10,),
                  const Text('İstifadəçi Girişi',style: TextStyle(
                    fontSize: 22
                  ),),
                ],
              ),
              const SizedBox(height: 25),
              const Text('E-mail adresi',style:TextStyle(fontSize: 17)),
              const SizedBox(height: 10),
              Stack(
                children: [
                  TextFormField(
                    controller: email,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder()
                    ),
                  ),
                  const Positioned(
                    top: 20,
                    right: 20,
                    child: Icon(Icons.mail_outline_rounded,color:colorHome,),
                  )
                ],
              ),
              const SizedBox(height: 25),
              const Text('Şifrə',style:TextStyle(fontSize: 17)),
              const SizedBox(height: 10),
              Stack(
                children: [
                  TextFormField(
                    controller: password,
                    obscureText: isObscureText,
                    keyboardType: TextInputType.visiblePassword,
                    decoration:const InputDecoration(
                        border: OutlineInputBorder()
                    ),
                  ),
                   Positioned(
                    top: 8,
                    right: 10,
                    child: IconButton(
                        onPressed: (){
                          setState(() {
                            isObscureText = !isObscureText;
                          });
                        },
                        icon:isObscureText==true
                      ? const Icon(Icons.remove_red_eye_outlined,color:colorHome,)
                            : const Icon(Icons.visibility_off,color:colorHome,)
                    )
                  )
                ],
              ),
              const SizedBox(height: 25),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    onPressed: (){
                      EasyLoading.show(status: 'Bir qədər gözləyin...',maskType: EasyLoadingMaskType.custom);
                      FocusScope.of(context).unfocus();
                      login();
                    },
                    child: const Text('Daxil ol',style: TextStyle(color: Colors.white,
                        fontSize: 18),),
                    style: ElevatedButton.styleFrom(
                      elevation: 7,
                        shadowColor: const Color(0xFF9ECFF8),
                        backgroundColor: Colors.blue,
                        minimumSize: const Size(180,60),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        )
                    ),
                  ),
                  TextButton(
                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>const ForgetPassword()));
                      },
                      child: const Text('Şifrəni unutmusuz?')
                  )
                ],
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>const Registration()));
                  },
                  child: const Text('Yeni Qeydiyyat',style: TextStyle(color: Colors.white,
                      fontSize: 18),),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: colorHome,
                      minimumSize: const Size(180,60),
                      shadowColor: const Color(0xFFFFE0BF),
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      )
                  ),
                ),
              ),
              const SizedBox(height: 20)
            ],
          ),
        ),
      ),
    );
  }
}

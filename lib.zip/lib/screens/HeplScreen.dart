import 'package:flutter/material.dart';
import 'package:linzaplanet/screens/Contact.dart';

import '../component/color.dart';

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: Column(
        children: [
          ListTile(
            leading: Icon(Icons.arrow_forward_ios,size: 16,color:colorHome),
            title: Text('Bizimlə əlaqə'),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Contact()));
            },
          ),
        ],
      ),
    );
  }
}

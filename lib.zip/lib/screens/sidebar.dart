import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/main.dart';
import 'package:linzaplanet/screens/Profile.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../categories/PageCategories.dart';
import 'Brends.dart';
import 'LensType.dart';

class Sidebar extends StatefulWidget {
  const Sidebar({super.key});

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 330,
      child: Drawer(
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: const Color(0xFFffffff),
            child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      height: 400,
                      child: Image.asset('assets/sidebarBack.jpeg',fit: BoxFit.cover,),
                    ),
                    Positioned(
                        bottom: 10,
                        left: 10,
                        child: Row(
                          children: [
                            const CircleAvatar(
                              radius: 30,
                            ),
                            const SizedBox(width:10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('${sharedPreferences.getString('username')}',
                                      style:const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 19
                                      ),),
                                    IconButton(
                                        onPressed: (){
                                          Navigator.pop(context);
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Profile()));
                                        },
                                        icon: Icon(Icons.open_in_new)
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                    )
                  ],
                ),
                SizedBox(height:20),
                ListTile(
                  title: Text('Markalar'),
                  trailing: Icon(Icons.arrow_forward_ios,size: 16,),
                  leading: Icon(Icons.language_outlined),
                  onTap: (){
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Brends()));
                  },
                ),

                ListTile(
                  title: Text('Linza Tipləri'),
                  trailing: Icon(Icons.arrow_forward_ios,size: 16,),
                  leading: Icon(Icons.adjust),
                  onTap: (){
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LensType()));
                  },
                ),

                const ListTile(
                  title: Text('Xüsusi linzalar'),
                  leading: Icon(Icons.star_border),
                ),

                const ListTile(
                  title: Text('Kampaniyalar'),
                  leading: Icon(Icons.local_offer_outlined),
                ),

                ListTile(
                  title: Text('Linza suları'),
                  leading: Icon(Icons.water_drop_outlined),
                  onTap: (){
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>PageCategories(seflink: 'linzasuyu')));
                  },
                ),
              ],
            ),
          ),
        ),

      ),
    );
  }
}

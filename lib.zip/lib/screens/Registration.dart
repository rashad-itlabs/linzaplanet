import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:linzaplanet/main.dart';
import 'package:linzaplanet/screens/HomeScreen.dart';
import 'package:linzaplanet/screens/Profile.dart';
import 'package:linzaplanet/screens/home.dart';
import '../component/color.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mask/mask.dart';
import 'package:get/get.dart';

class Registration extends StatefulWidget {
  const Registration({super.key});

  @override
  State<Registration> createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {
  var isObscureText;


  final formKey = GlobalKey<FormState>();
  TextEditingController name = TextEditingController();
  TextEditingController surname = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController username = TextEditingController();

  String? forToast;

  Future registration() async{

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    final url = Uri.parse('https://linzaplanet.az/api/registration');
    var response = await http.post(url, body: {
      'name':name.text,
      'surname':surname.text,
      'username':username.text,
      'email':email.text,
      'phone':phone.text,
      'password':password.text
    });
    var result = jsonDecode(response.body);
    if(result['messages']=='true'){
      EasyLoading.showSuccess(
          'Qeydiyyatınız tamamlandı',maskType: EasyLoadingMaskType.custom);
      EasyLoading.dismiss();
      forToast = 'Qeydiyyatınız uğurla tamamlandı';
      setState(() {
        sharedPreferences.setString('token', email.text);
        sharedPreferences.setString('username', username.text);
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (BuildContext context) => Home()),
                (Route<dynamic> route) => false);
      });
    }else{
      EasyLoading.showError(result['messages'],maskType: EasyLoadingMaskType.custom);
      EasyLoading.dismiss();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isObscureText = true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                          color: colorHome,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      child: Icon(Icons.person_add_rounded,color: Colors.white,),
                    ),
                    const SizedBox(width: 10,),
                    const Text('Yeni İstifadəçi',style: TextStyle(
                        fontSize: 22
                    ),),
                  ],
                ),
                const SizedBox(height: 25),
                const Text('Ad',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: name,
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Bu xananı boş saxlamayın';
                        }
                        return null;
                      },
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.person,color:colorHome,),
                    )
                  ],
                ),
                const SizedBox(height: 25),

                const Text('Soyad',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: surname,
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Bu xananı boş saxlamayın';
                        }
                        return null;
                      },
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.person,color:colorHome,),
                    )
                  ],
                ),

                const SizedBox(height: 25),

                const Text('İstifadəçi adı',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: username,
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Bu xananı boş saxlamayın';
                        }
                        return null;
                      },
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.person,color:colorHome,),
                    )
                  ],
                ),

                const SizedBox(height: 25),

                const Text('Telefon',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: phone,
                      obscureText: false,
                      keyboardType: TextInputType.phone,
                      inputFormatters: [
                        Mask.generic(
                          masks: ['(###)###-##-##'],
                          hashtag: Hashtag.numbers, // optional field
                        ),
                      ],
                      decoration:const InputDecoration(
                          border: OutlineInputBorder(),
                        hintText: '050 000-00-00'
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Bu xananı boş saxlamayın';
                        }
                        return null;
                      },
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.phone,color:colorHome,),
                    )
                  ],
                ),

                const SizedBox(height: 25),
                const Text('E-mail adresi',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: email,
                      obscureText: false,
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                      validator: (value) {
                        if(value!.isEmpty){
                          return "E-mail adresinizi yazın";
                        }
                        if(!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]")
                            .hasMatch(value)){
                          return "Email adresinizi düzgün yazın";
                        }
                        return null;
                      },
                    ),
                    const Positioned(
                      top: 20,
                      right: 20,
                      child: Icon(Icons.mail_outline_rounded,color:colorHome,),
                    )
                  ],
                ),

                const SizedBox(height: 25),
                const Text('Şifrə',style:TextStyle(fontSize: 17)),
                const SizedBox(height: 10),
                Stack(
                  children: [
                    TextFormField(
                      controller: password,
                      obscureText: isObscureText,
                      decoration:const InputDecoration(
                          border: OutlineInputBorder()
                      ),
                      validator: (value) {
                        if(value!.isEmpty){
                          return "Şifrənizi yazın";
                        }
                        if(value.length < 3){
                          return "Şifrənizi 3 simvoldan çox olmalıdır";
                        }
                        return null;
                      },
                    ),
                    Positioned(
                        top: 8,
                        right: 10,
                        child: IconButton(
                            onPressed: (){
                              setState(() {
                                isObscureText = !isObscureText;
                              });
                            },
                            icon:isObscureText==true
                                ? Icon(Icons.remove_red_eye_outlined,color:colorHome,)
                                : Icon(Icons.visibility_off,color:colorHome,)
                        )
                    )
                  ],
                ),

                const SizedBox(height: 25),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: (){

                        if (formKey.currentState!.validate()) {
                          EasyLoading.show(status: 'Bir qədər gözləyin...',maskType: EasyLoadingMaskType.custom);
                          FocusScope.of(context).unfocus();
                          registration();
                          // ScaffoldMessenger.of(context).showSnackBar(
                          //    SnackBar(content: Text('${forToast}')),
                          // );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: colorHome,
                          minimumSize: Size(180,60),
                          shadowColor: Color(0xFFFFE0BF),
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          )
                      ),
                      child:const Text('Qeydiyyatdan keç',style: TextStyle(color: Colors.white,
                          fontSize: 18),),
                    ),
                  ],
                ),
                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

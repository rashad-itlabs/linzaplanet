import 'package:flutter/material.dart';
import 'package:linzaplanet/categories/PageCategories.dart';
import 'package:linzaplanet/screens/Brends.dart';
import 'package:linzaplanet/screens/LensType.dart';

class Categories extends StatefulWidget {
  const Categories({super.key});

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body: Column(
        children: [
          ListTile(
            title: Text('Markalar'),
            trailing: Icon(Icons.arrow_forward_ios,size: 16,),
            leading: Icon(Icons.language_outlined),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Brends()));
            },
          ),

          ListTile(
            title: Text('Linza Tipləri'),
            trailing: Icon(Icons.arrow_forward_ios,size: 16,),
            leading: Icon(Icons.adjust),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>LensType()));
            },
          ),

          ListTile(
            title: Text('Linza suları'),
            leading: Icon(Icons.water_drop_outlined),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>PageCategories(seflink: 'linzasuyu')));
            },
          ),

          const ListTile(
            title: Text('Xüsusi linzalar'),
            leading: Icon(Icons.star_border),
          ),

          const ListTile(
            title: Text('Kampaniyalar'),
            leading: Icon(Icons.local_offer_outlined),
          ),
        ],
      )
    );
  }
}

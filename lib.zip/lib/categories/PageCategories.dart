import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:linzaplanet/modal/lensType.dart';

import '../component/color.dart';
import '../modal/LensForTypeList.dart';
import '../screens/ProductInfo.dart';

class PageCategories extends StatefulWidget {
  String seflink;
  PageCategories({super.key, required this.seflink});

  @override
  State<PageCategories> createState() => _PageCategoriesState();
}

class _PageCategoriesState extends State<PageCategories> {
  int count = 0;
  var list;

  Future getByBrends() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/forType/${widget.seflink}'));
    if(response.statusCode==200){
      var result = lenaForTypeListFromJson(response.body);
      setState(() {
        count = result.length;
        list = result;
      });
      return true;
    }else{
      throw Exception('Fatal Error');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getByBrends();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
      ),
      body:count !=0 ? GridView.builder(
          itemCount: count,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisExtent: 280
          ),
          itemBuilder: (context, index){
            return Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 280,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border:const Border(
                        left: BorderSide(color: Colors.black12,width: 1),
                        right: BorderSide(color: Colors.black12,width: 1),
                        top: BorderSide(color: Colors.black12,width: 1),
                        bottom: BorderSide(color: Colors.black12,width: 1),
                      ),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Image.network('${list[index].proImage}',width: 140,height: 90,),
                        Padding(
                          padding:EdgeInsets.all(8.0),
                          child: Text('${list[index].proName}',textAlign: TextAlign.center,style:const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          )),
                        ),
                        SizedBox(height:10),
                        Spacer(),
                        const Padding(
                          padding:  EdgeInsets.all(8.0),
                          child: Divider(height: 1,color: Colors.black12,),
                        ),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.only(left:10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${list[index].proPrice} Azn',textAlign: TextAlign.center,style:const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                              IconButton(
                                  onPressed: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink:list[index].seflink)));
                                  },
                                  icon: Icon(Icons.arrow_forward,color: colorHome,)
                              )
                            ],
                          ),
                        ),
                        SizedBox(height:5),
                      ],
                    ),
                  ),
                ),
                if(list[index].position == 'Yeni')
                  Positioned(
                    top: 20,
                    child: Container(
                      padding: EdgeInsets.all(10),
                      color: Colors.green,
                      child:const Text("Yeni",style: TextStyle(
                          color: Colors.white
                      ),),
                    ),
                  )
              ],
            );
          }
      ):Center(child: CircularProgressIndicator(),),
    );
  }
}

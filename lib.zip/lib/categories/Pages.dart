import 'dart:async';

import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:http/http.dart' as http;
import 'package:linzaplanet/modal/getByBrends.dart';

import '../screens/ProductInfo.dart';

class Pages extends StatefulWidget {
  String seflink;
  String brand;
  Pages({super.key, required this.seflink, required this.brand});

  @override
  State<Pages> createState() => _PagesState();
}

class _PagesState extends State<Pages> {
  final scrollController = ScrollController();
  int _currentIndex = 0;
  final PageController _controller = PageController();
  final PageController _controller_2 = PageController();


  List imagelist = [
    {'id':1,"image_path":"assets/image_1.jpeg"},
    {'id':2,"image_path":"assets/image_2.webp"},
  ];
  final CarouselController carouselController = CarouselController();
  int currentIndex = 0;
  int count = 0;
  var list;

  Future getByBrends() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/byBrands/${widget.seflink}'));
    if(response.statusCode==200){
      var result = getByBrandsFromJson(response.body);
      setState(() {
        count = result.length;
        list = result;
      });
      return true;
    }else{
      throw Exception('Fatal Error');
    }
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getByBrends();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: Image.asset('assets/logo_my.png',width: 170,),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: Text('${widget.brand}'),
          ),
        ],
      ),
      body: GridView.builder(
        itemCount: count,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisExtent: 280
          ),
          itemBuilder: (context, index){
            return Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 280,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border:const Border(
                        left: BorderSide(color: Colors.black12,width: 1),
                        right: BorderSide(color: Colors.black12,width: 1),
                        top: BorderSide(color: Colors.black12,width: 1),
                        bottom: BorderSide(color: Colors.black12,width: 1),
                      ),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Image.network('${list[index].proImage}',width: 140,height: 90,),
                         Padding(
                          padding:EdgeInsets.all(8.0),
                          child: Text('${list[index].proName}',textAlign: TextAlign.center,style:const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          )),
                        ),
                        SizedBox(height:10),
                        Spacer(),
                        const Padding(
                          padding:  EdgeInsets.all(8.0),
                          child: Divider(height: 1,color: Colors.black12,),
                        ),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.only(left:10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${list[index].proPrice} Azn',textAlign: TextAlign.center,style:const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                              IconButton(
                                  onPressed: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink:list[index].seflink)));
                                  },
                                  icon: Icon(Icons.arrow_forward,color: colorHome,)
                              )
                            ],
                          ),
                        ),
                        SizedBox(height:5),
                      ],
                    ),
                  ),
                ),
                if(list[index].position == 'Yeni')
                Positioned(
                  top: 20,
                    child: Container(
                      padding: EdgeInsets.all(10),
                      color: Colors.green,
                      child:const Text("Yeni",style: TextStyle(
                        color: Colors.white
                      ),),
                    ),
                )
              ],
            );
          }
      ),
    );
  }
}

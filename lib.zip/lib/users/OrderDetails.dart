import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linzaplanet/component/color.dart';

class OrderDetail extends StatefulWidget {
  const OrderDetail({super.key});

  @override
  State<OrderDetail> createState() => _OrderDetailState();
}

class _OrderDetailState extends State<OrderDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const Text('Sifariş haqqında ətraflı'),
      ),
      body: ListView.builder(
        itemCount: 2,
          itemBuilder: (_, index){
            return Container(
              padding: const EdgeInsets.all(10),
              child: Card(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          margin: const EdgeInsets.all(10),
                          width: 120,
                          height: 180,
                          decoration: const BoxDecoration(
                            border: Border(
                                left: BorderSide(color: Colors.black38,width: 1),
                                right: BorderSide(color: Colors.black38,width: 1),
                                top: BorderSide(color: Colors.black38,width: 1),
                                bottom: BorderSide(color: Colors.black38,width: 1)
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          child:const Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Air Optix Colors',style:TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 14
                              )),
                              SizedBox(height: 5),
                              Text('Məhsul haqqında qısa açıqlama'),
                              SizedBox(height: 5),
                              Text('Ədəd: 1'),
                              SizedBox(height:5),
                              Text('32.00 Azn',style:TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17,
                                color: colorHome
                              )),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height:10),
                    const Divider(height: 1,color: Colors.black26,),
                    const SizedBox(height:10),
                    Row(
                      children: [
                        IconButton(
                            onPressed: (){
                              showCupertinoDialog(
                                  context: context,
                                  builder: (context)=> CupertinoAlertDialog(
                                    title: Text('Oops!'),
                                    content: Text('Silmək istədiyinizdən əminsiniz?'),
                                    actions: [
                                      CupertinoDialogAction(
                                        onPressed: (){
                                          Navigator.pop(context);
                                        },
                                        child: const Text('İmtina',style:TextStyle(color:Colors.redAccent)),
                                      ),
                                      CupertinoDialogAction(
                                        child: const Text('Bəli'),
                                        onPressed: (){
                                          Navigator.pop(context);
                                        },
                                      ),
                                    ],
                                  )
                              );
                            },
                            icon: const Icon(Icons.delete_outline,color: Colors.redAccent,)
                        ),
                        const SizedBox(width:5),
                        const Text('Məhsulu sifarişlərim listindən sil')
                      ],
                    )
                  ],
                ),
              ),
            );
          }
      )
    );
  }
}

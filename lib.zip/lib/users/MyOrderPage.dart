import 'package:flutter/material.dart';
import 'package:linzaplanet/modal/my_orders.dart';
import 'package:linzaplanet/users/OrderDetails.dart';
import 'package:http/http.dart' as http;

import '../component/color.dart';

class MyOrder extends StatefulWidget {
  const MyOrder({super.key});

  @override
  State<MyOrder> createState() => _MyOrderState();
}

class _MyOrderState extends State<MyOrder> {

  int count = 0;
  var list;


  Future listOrder() async{
    final response = await http.get(Uri.parse('https://linzaplanet.az/api/showCard'));
    if(response.statusCode==200){
      var result = myOrdersFromJson(response.body);
      setState(() {
        count = result.length;
        list = result;
      });
      return true;
    }else{
      throw Exception('Texniki xəta');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    listOrder();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Colors.white,
        title: const Text('Sifarişlərim')
      ),
      body: ListView.builder(
          itemCount: count,
          itemBuilder: (_, index){
            return Container(
              padding: const EdgeInsets.only(left: 7, right: 7),
              child: Card(
                margin: EdgeInsets.only(top:5,bottom: 20),
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.only(left:7,top: 10,bottom: 10),
                          child: Column(
                            children: [
                              Text('${list[index].data}'),
                              const SizedBox(height:7,),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: RichText(
                                  text: TextSpan(
                                    text: 'Toplam:',
                                    style:const TextStyle(color:Colors.black54,
                                        fontWeight: FontWeight.w600),
                                    children: [
                                      TextSpan(text: '${list[index].price} Azn', style:const TextStyle(fontWeight: FontWeight.bold,color: colorHome)),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        TextButton(
                            onPressed: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>const OrderDetail()));
                            },
                            child: const Text('Ətraflı')
                        )
                      ],
                    ),
                    const Divider(height:1,color: Colors.black26,),
                    const SizedBox(height: 5,),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${list[index].proName}',style:const TextStyle(
                            fontWeight: FontWeight.w700
                          ),),
                          const SizedBox(height: 10),
                          const Text('Bizi seçdiyiniz üçün təşəkkürlər',
                              style:TextStyle(
                                  fontSize: 13
                              )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
      ),
    );
  }
}

import 'package:flutter/material.dart';

class AboutApp extends StatefulWidget {
  const AboutApp({super.key});

  @override
  State<AboutApp> createState() => _AboutAppState();
}

class _AboutAppState extends State<AboutApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo_my.png',width: 300,),
            SizedBox(height:5,),
            Text('version:1.0.0'),
            SizedBox(height:5,),
            Text('www.linzaplanet.az'),
            SizedBox(height:150),
          ],
        ),
      ),
    );
  }
}

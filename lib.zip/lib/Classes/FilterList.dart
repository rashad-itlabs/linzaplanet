import 'package:flutter/material.dart';

import '../screens/ProductInfo.dart';
import '../screens/SearchProductDetail.dart';

class MySearchDelegate extends SearchDelegate{

  List<Map<String, String>> serachResults = [
    {
      "id": "2",
      "pro_name": "FRESHLOOK COLORS",
      "pro_image": "https://linzaplanet.az/upload/freshlook-colors.jpg",
      "pro_price": "27.00",
      "seflink": "freshlook-colors"
    },
    {
      "id": "3",
      "pro_name": "FRESHLOOK ONEDAY",
      "pro_image": "https://linzaplanet.az/upload/flod_(2)1.jpg",
      "pro_price": "32.00",
      "seflink": "freshlook-oneday"
    },
    {
      "id": "4",
      "pro_name": "FRESHLOOK COLORBLENDS",
      "pro_image": "https://linzaplanet.az/upload/freshlook-numarali.jpg",
      "pro_price": "27.00",
      "seflink": "freshlook-colorblends"
    },
    {
      "id": "5",
      "pro_name": "Dailies Total 1",
      "pro_image": "https://linzaplanet.az/upload/dailies_total1-30-800x2847.jpg",
      "pro_price": "75.00",
      "seflink": "dailies-total-1"
    },
    {
      "id": "6",
      "pro_name": "Air Optix Colors",
      "pro_image": "https://linzaplanet.az/upload/Air-Optix-Colour1.jpg",
      "pro_price": "35.00",
      "seflink": "air-optix-colors"
    },
    {
      "id": "7",
      "pro_name": "AIR OPTIX NIGHT & DAY (6)",
      "pro_image": "https://linzaplanet.az/upload/air-optix-night-day.jpg",
      "pro_price": "85.00",
      "seflink": "air-optix-night-day-aqua"
    },
    {
      "id": "10",
      "pro_name": "Precision 1",
      "pro_image": "https://linzaplanet.az/upload/3348_front-magento-jpg-centered2.jpg",
      "pro_price": "54.00",
      "seflink": "precision-1"
    },
    {
      "id": "11",
      "pro_name": "DAILIES AquaComfort Plus(30)",
      "pro_image": "https://linzaplanet.az/upload/dailies-aqua.jpg",
      "pro_price": "35.00",
      "seflink": "dailies-aquacomfort-plus30"
    },
    {
      "id": "13",
      "pro_name": "AIR OPTIX for Astigmatism (6)",
      "pro_image": "https://linzaplanet.az/upload/air-optix-hydraglyde-toric-1-o.jpg",
      "pro_price": "80.00",
      "seflink": "air-optix-for-astigmatism-6"
    },
    {
      "id": "14",
      "pro_name": "Air Optix HydraGlyde (6)",
      "pro_image": "https://linzaplanet.az/upload/air-optix-hydraglyde.jpg",
      "pro_price": "42.00",
      "seflink": "air-optix-hydraglyde-6"
    },
    {
      "id": "16",
      "pro_name": "Acuvue Oasys 1-Day with HydraLuxe",
      "pro_image": "https://linzaplanet.az/upload/oasys-1day.jpg",
      "pro_price": "47.00",
      "seflink": "acuvue-oasys-1-day-with-hydraluxe"
    },
    {
      "id": "17",
      "pro_name": "ACUVUE OASYS FOR ASTIGMATISM",
      "pro_image": "https://linzaplanet.az/upload/oasys-toric.jpg",
      "pro_price": "69.00",
      "seflink": "acuvue-oasys-for-astigmatism"
    },
    {
      "id": "18",
      "pro_name": "ACUVUE OASYS HYDRACLEAR Plus",
      "pro_image": "https://linzaplanet.az/upload/oasys.jpg",
      "pro_price": "35.00",
      "seflink": "acuvue-oasys-hydraclear-plus"
    },
    {
      "id": "19",
      "pro_name": "1 DAY ACUVUE TRUEYE",
      "pro_image": "https://linzaplanet.az/upload/trueye.jpg",
      "pro_price": "49.00",
      "seflink": "1-day-acuvue-trueye"
    },
    {
      "id": "21",
      "pro_name": "1 DAY ACUVUE MOIST",
      "pro_image": "https://linzaplanet.az/upload/moist.jpg",
      "pro_price": "40.00",
      "seflink": "1-day-acuvue-moist"
    },
    {
      "id": "23",
      "pro_name": "DAILIES AquaComfort Plus (Toric-30)",
      "pro_image": "https://linzaplanet.az/upload/dailies-aqua-toric.jpg",
      "pro_price": "75.00",
      "seflink": "dailies-aquacomfort-plus-toric-30"
    },
    {
      "id": "53",
      "pro_name": "DESIO - COFFEE COLLECTION",
      "pro_image": "https://linzaplanet.az/upload/desio2.jpg",
      "pro_price": "85.00",
      "seflink": "desio---coffee-collection"
    },
    {
      "id": "55",
      "pro_name": "Pure Vision 2 HD",
      "pro_image": "https://linzaplanet.az/upload/0045878_purevision-2-hd_4202.png",
      "pro_price": "50.00",
      "seflink": "pure-vision-2-hd"
    },
    {
      "id": "56",
      "pro_name": "BIO TRUE ONE DAY ",
      "pro_image": "https://linzaplanet.az/upload/51xCKkkdq1L._SL1000_1.jpg",
      "pro_price": "33.00",
      "seflink": "bio-true-one-day-"
    },
    {
      "id": "57",
      "pro_name": "My Day",
      "pro_image": "https://linzaplanet.az/upload/2334_front-jpg-centred3.jpg",
      "pro_price": "38.00",
      "seflink": "my-day"
    },
    {
      "id": "58",
      "pro_name": "BIOFINITY",
      "pro_image": "https://linzaplanet.az/upload/990x800_biofinitysphere1.png",
      "pro_price": "58.00",
      "seflink": "biofinity"
    },
    {
      "id": "60",
      "pro_name": "CONTACT ZEİSS",
      "pro_image": "https://linzaplanet.az/upload/contact-day30-1-o1.jpg",
      "pro_price": "46.00",
      "seflink": "contact-zeiss"
    },
    {
      "id": "61",
      "pro_name": "CONTACT ZEISS (YÜKSƏK OPTİK DƏRƏCƏ)",
      "pro_image": "https://linzaplanet.az/upload/contact-day30-1-o2.jpg",
      "pro_price": "55.00",
      "seflink": "contact-zeiss-yuksek-optik-derece"
    },
    {
      "id": "63",
      "pro_name": "AVAİRA VİTALİTY",
      "pro_image": "https://linzaplanet.az/upload/avaira-vitality-1-o1.jpg",
      "pro_price": "35.00",
      "seflink": "avaira-vitality"
    },
    {
      "id": "64",
      "pro_name": "BIOMEDICS 55",
      "pro_image": "https://linzaplanet.az/upload/COOPERVISION-BIOMEDICS-55-EVOLUTION-3733_HD1.jpg",
      "pro_price": "45.00",
      "seflink": "biomedics-55"
    },
    {
      "id": "65",
      "pro_name": "BIO TRUE 300 ML",
      "pro_image": "https://linzaplanet.az/upload/1_org1.jpg",
      "pro_price": "15.00",
      "seflink": "bio-true-300-ml"
    },
    {
      "id": "66",
      "pro_name": "REVITA LENS LINZA SUYU",
      "pro_image": "https://linzaplanet.az/upload/revita2.jpg",
      "pro_price": "15.00",
      "seflink": "revita-lens-linza-suyu"
    },
    {
      "id": "67",
      "pro_name": "SOFLENS",
      "pro_image": "https://linzaplanet.az/upload/soflens-59-contact-lenses3.jpg",
      "pro_price": "33.00",
      "seflink": "soflens"
    },
    {
      "id": "68",
      "pro_name": "ACUVUE TRANSITIONS",
      "pro_image": "https://linzaplanet.az/upload/oasys-transitions-1-l_(1).jpg",
      "pro_price": "38.00",
      "seflink": "acuvue-transitions"
    },
    {
      "id": "69",
      "pro_name": "ALL IN ONE LIGHT",
      "pro_image": "https://linzaplanet.az/upload/all-in-one-360-1-o1.jpg",
      "pro_price": "14.00",
      "seflink": "all-in-one-light"
    },
    {
      "id": "70",
      "pro_name": "RENU MULTIPLUS 360 ML",
      "pro_image": "https://linzaplanet.az/upload/renu-multiplus-1x360ml3.jpg",
      "pro_price": "15.00",
      "seflink": "renu-multiplus-360-ml"
    }
  ];
  @override
  Widget buildLeading(BuildContext context)=>IconButton(
      onPressed: () => close(context, null),
      icon: Icon(Icons.arrow_back)
  );

  @override
  List<Widget> buildActions(BuildContext context) => [
    IconButton(
        onPressed: (){
          if(query.isEmpty){
            close(context, null);
          }else{
            query = '';
          }
        },
        icon: Icon(Icons.close)
    )
  ];

  @override
  Widget buildResults(BuildContext context){
    return SearchProductDetail();
  }

  @override
  Widget buildSuggestions(BuildContext context){
    List<Map<String, String>> suggestions = serachResults.where((result) {
      final title = result['pro_name']!.toLowerCase();
      final input = query.toLowerCase();

      return title.contains(input);
    }).toList();
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(top: 10,bottom: 10),
          height: 75,
          color: Colors.white,
          child: Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/seffaf-lens-6.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/multifocal-uzak-yakin-lens-14.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/seffaf-lens-61.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/firsat-paketleri-2.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/toric-lens-astigmatli14.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
                InkWell(
                  child: Container(
                    decoration:const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12, spreadRadius: 1)],
                    ),
                    child:const CircleAvatar(
                      radius: 45,
                      backgroundColor: Colors.white,
                      backgroundImage: NetworkImage('https://linzaplanet.az/upload/cats/lens-solusyonu-2.jpg'),
                    ),
                  ),
                  onTap: (){},
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
              itemCount: suggestions.length,
              itemBuilder: (context, index){
                final suggestion = suggestions[index];
                return ListTile(
                  leading:const CircleAvatar(
                    child: Text('L'),
                  ),
                  title: Text(suggestion['pro_name']!),
                  subtitle: Text('${suggestion['pro_price']} Azn',
                  style:const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600
                  ),),
                  onTap: (){
                    query = suggestion['pro_name']!;
                    close(context, null);
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductInfo(seflink: suggestion['seflink'].toString())));
                    // showResults(context);
                  },
                );
              }
          ),
        ),
      ],
    );
  }


}
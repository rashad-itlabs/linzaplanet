import 'package:flutter/material.dart';
import 'package:linzaplanet/component/Extension/app_common.dart';
import 'package:linzaplanet/component/color.dart';
import 'package:linzaplanet/screens/home.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

late SharedPreferences sharedPreferences;

void main() async {
  runApp(const MyApp());
  SharedPreferences.setMockInitialValues({});
  sharedPreferences = await SharedPreferences.getInstance();

  configLoading();
}



class MyApp extends StatelessWidget {

  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Linza Planet',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orangeAccent),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Linza Planet'),
      builder: EasyLoading.init(),
    );
  }
}

void configLoading() {

  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 3000)
    ..indicatorType = EasyLoadingIndicatorType.fadingCircle
    ..loadingStyle = EasyLoadingStyle.custom
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.black87
    ..backgroundColor = Colors.white
    ..indicatorColor = Colors.black87
    ..textColor = Colors.black87
    ..maskColor = const Color(0xfffd9947).withOpacity(0.4)
    ..userInteractions = true
    ..dismissOnTap = false;
  //..customAnimation = CustomAnimation();
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late SharedPreferences sharedPreferences;
  String userEmail='';




  Future _getShared() async{
    final SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var sessionEmail = sharedPreferences.getString('token');
    setState(() {
      userEmail = sessionEmail!;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getShared();
    Future.delayed(
      Duration(seconds: 3),
          () async {
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (BuildContext context) => const Home()),
                (Route<dynamic> route) => false);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: colorHome,
        child: Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Spacer(),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Linza', style: TextStyle(
                    fontSize: 50,
                    color: Colors.white
                  ),),
                  Text('Planet', style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 60
                  ),),
                ],
              ),
              Spacer(),
              Container(
                height: 50,
                child: Text('www.linzaplanet.az',
                  textAlign: TextAlign.center,
                  style: normalTextstyle(),),
              )
            ],
          ),
        ),
      ) // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

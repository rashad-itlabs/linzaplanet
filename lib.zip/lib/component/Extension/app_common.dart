import 'package:flutter/material.dart';
import 'package:linzaplanet/main.dart';

TextStyle normalTextstyle({int? size, Color? color}){
  return TextStyle(
    color:Colors.white,
    fontSize: 16,
  );
}
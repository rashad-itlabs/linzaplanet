// To parse this JSON data, do
//
//     final monthlyLenses = monthlyLensesFromJson(jsonString);

import 'dart:convert';

List<MonthlyLenses> monthlyLensesFromJson(String str) => List<MonthlyLenses>.from(json.decode(str).map((x) => MonthlyLenses.fromJson(x)));

String monthlyLensesToJson(List<MonthlyLenses> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class MonthlyLenses {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String brandName;
  String seflink;

  MonthlyLenses({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.brandName,
    required this.seflink,
  });

  factory MonthlyLenses.fromJson(Map<String, dynamic> json) => MonthlyLenses(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    brandName: json["brand_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "brand_name": brandName,
    "seflink": seflink,
  };
}

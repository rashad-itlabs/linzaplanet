// To parse this JSON data, do
//
//     final lensType = lensTypeFromJson(jsonString);

import 'dart:convert';

List<LensType> lensTypeFromJson(String str) => List<LensType>.from(json.decode(str).map((x) => LensType.fromJson(x)));

String lensTypeToJson(List<LensType> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class LensType {
  String lensName;
  String seflink;

  LensType({
    required this.lensName,
    required this.seflink,
  });

  factory LensType.fromJson(Map<String, dynamic> json) => LensType(
    lensName: json["lens_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "lens_name": lensName,
    "seflink": seflink,
  };
}

// To parse this JSON data, do
//
//     final getByBrands = getByBrandsFromJson(jsonString);

import 'dart:convert';

List<GetByBrands> getByBrandsFromJson(String str) => List<GetByBrands>.from(json.decode(str).map((x) => GetByBrands.fromJson(x)));

String getByBrandsToJson(List<GetByBrands> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class GetByBrands {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String seflink;

  GetByBrands({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.seflink,
  });

  factory GetByBrands.fromJson(Map<String, dynamic> json) => GetByBrands(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "seflink": seflink,
  };
}

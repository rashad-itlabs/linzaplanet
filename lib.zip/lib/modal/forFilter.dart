// To parse this JSON data, do
//
//     final filterArray = filterArrayFromJson(jsonString);

import 'dart:convert';

List<FilterArray> filterArrayFromJson(String str) => List<FilterArray>.from(json.decode(str).map((x) => FilterArray.fromJson(x)));

String filterArrayToJson(List<FilterArray> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class FilterArray {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String seflink;

  FilterArray({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.seflink,
  });

  factory FilterArray.fromJson(Map<String, dynamic> json) => FilterArray(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "seflink": seflink,
  };
}

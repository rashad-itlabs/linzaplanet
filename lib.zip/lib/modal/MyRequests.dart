// To parse this JSON data, do
//
//     final myOrders = myOrdersFromJson(jsonString);

import 'dart:convert';

List<MyOrders> myOrdersFromJson(String str) => List<MyOrders>.from(json.decode(str).map((x) => MyOrders.fromJson(x)));

String myOrdersToJson(List<MyOrders> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class MyOrders {
  int id;
  String nameSurname;
  String phone;
  String status;
  String startAddress;
  double rideAmount;
  String startLatitude;
  String startLongitude;
  String endAdress;
  String endLatitude;
  String endLongitude;
  dynamic addressTwo;
  String extraEndLatitude;
  String extraEndLongitude;
  dynamic addressThree;
  dynamic addressFour;
  dynamic latitudeThree;
  dynamic longitudeThree;
  dynamic latitudeFour;
  dynamic longitudeFour;
  DateTime dateRequest;

  MyOrders({
    required this.id,
    required this.nameSurname,
    required this.phone,
    required this.status,
    required this.startAddress,
    required this.rideAmount,
    required this.startLatitude,
    required this.startLongitude,
    required this.endAdress,
    required this.endLatitude,
    required this.endLongitude,
    required this.addressTwo,
    required this.extraEndLatitude,
    required this.extraEndLongitude,
    required this.addressThree,
    required this.addressFour,
    required this.latitudeThree,
    required this.longitudeThree,
    required this.latitudeFour,
    required this.longitudeFour,
    required this.dateRequest,
  });

  factory MyOrders.fromJson(Map<String, dynamic> json) => MyOrders(
    id: json["id"],
    nameSurname: json["name_surname"],
    phone: json["phone"],
    status: json["status"],
    startAddress: json["start_address"],
    rideAmount: json["ride_amount"]?.toDouble(),
    startLatitude: json["start_latitude"],
    startLongitude: json["start_longitude"],
    endAdress: json["end_adress"],
    endLatitude: json["end_latitude"],
    endLongitude: json["end_longitude"],
    addressTwo: json["address_two"],
    extraEndLatitude: json["extra_end_latitude"],
    extraEndLongitude: json["extra_end_longitude"],
    addressThree: json["address_three"],
    addressFour: json["address_four"],
    latitudeThree: json["latitude_three"],
    longitudeThree: json["longitude_three"],
    latitudeFour: json["latitude_four"],
    longitudeFour: json["longitude_four"],
    dateRequest: DateTime.parse(json["date_request"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name_surname": nameSurname,
    "phone": phone,
    "status": status,
    "start_address": startAddress,
    "ride_amount": rideAmount,
    "start_latitude": startLatitude,
    "start_longitude": startLongitude,
    "end_adress": endAdress,
    "end_latitude": endLatitude,
    "end_longitude": endLongitude,
    "address_two": addressTwo,
    "extra_end_latitude": extraEndLatitude,
    "extra_end_longitude": extraEndLongitude,
    "address_three": addressThree,
    "address_four": addressFour,
    "latitude_three": latitudeThree,
    "longitude_three": longitudeThree,
    "latitude_four": latitudeFour,
    "longitude_four": longitudeFour,
    "date_request": dateRequest.toIso8601String(),
  };
}

// To parse this JSON data, do
//
//     final productDetails = productDetailsFromJson(jsonString);

import 'dart:convert';

List<ProductDetails> productDetailsFromJson(String str) => List<ProductDetails>.from(json.decode(str).map((x) => ProductDetails.fromJson(x)));

String productDetailsToJson(List<ProductDetails> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ProductDetails {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String brandName;
  String typeLens;
  String category;
  String seflink;
  String proDetail;
  List<String> colorlist;
  List<String> numberlist;

  ProductDetails({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.brandName,
    required this.typeLens,
    required this.category,
    required this.seflink,
    required this.proDetail,
    required this.colorlist,
    required this.numberlist,
  });

  factory ProductDetails.fromJson(Map<String, dynamic> json) => ProductDetails(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    brandName: json["brand_name"],
    typeLens: json["type_lens"],
    category: json["category"],
    seflink: json["seflink"],
    proDetail: json["pro_detail"],
    colorlist: List<String>.from(json["colorlist"].map((x) => x)),
    numberlist: List<String>.from(json["numberlist"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "brand_name": brandName,
    "type_lens": typeLens,
    "category": category,
    "seflink": seflink,
    "pro_detail": proDetail,
    "colorlist": List<dynamic>.from(colorlist.map((x) => x)),
    "numberlist": List<dynamic>.from(numberlist.map((x) => x)),
  };
}

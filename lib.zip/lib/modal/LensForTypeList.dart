// To parse this JSON data, do
//
//     final lenaForTypeList = lenaForTypeListFromJson(jsonString);

import 'dart:convert';

List<LenaForTypeList> lenaForTypeListFromJson(String str) => List<LenaForTypeList>.from(json.decode(str).map((x) => LenaForTypeList.fromJson(x)));

String lenaForTypeListToJson(List<LenaForTypeList> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class LenaForTypeList {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String brandName;
  String seflink;

  LenaForTypeList({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.brandName,
    required this.seflink,
  });

  factory LenaForTypeList.fromJson(Map<String, dynamic> json) => LenaForTypeList(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    brandName: json["brand_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "brand_name": brandName,
    "seflink": seflink,
  };
}

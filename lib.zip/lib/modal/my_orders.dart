// To parse this JSON data, do
//
//     final myOrders = myOrdersFromJson(jsonString);

import 'dart:convert';

List<MyOrders> myOrdersFromJson(String str) => List<MyOrders>.from(json.decode(str).map((x) => MyOrders.fromJson(x)));

String myOrdersToJson(List<MyOrders> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class MyOrders {
  String shopId;
  String sifarisKodu;
  String username;
  String sessionId;
  String sessionEmail;
  String paySelect;
  String adress;
  String price;
  String quantity;
  String color;
  String ax;
  String cyl;
  String sph;
  String lenstype;
  String proImage;
  String proName;
  String activation;
  String data;

  MyOrders({
    required this.shopId,
    required this.sifarisKodu,
    required this.username,
    required this.sessionId,
    required this.sessionEmail,
    required this.paySelect,
    required this.adress,
    required this.price,
    required this.quantity,
    required this.color,
    required this.ax,
    required this.cyl,
    required this.sph,
    required this.lenstype,
    required this.proImage,
    required this.proName,
    required this.activation,
    required this.data,
  });

  factory MyOrders.fromJson(Map<String, dynamic> json) => MyOrders(
    shopId: json["shop_id"],
    sifarisKodu: json["sifaris_kodu"],
    username: json["username"],
    sessionId: json["sessionID"],
    sessionEmail: json["sessionEmail"],
    paySelect: json["pay_select"],
    adress: json["adress"],
    price: json["price"],
    quantity: json["quantity"],
    color: json["color"],
    ax: json["ax"],
    cyl: json["cyl"],
    sph: json["sph"],
    lenstype: json["lenstype"],
    proImage: json["pro_image"],
    proName: json["pro_name"],
    activation: json["activation"],
    data: json["data"],
  );

  Map<String, dynamic> toJson() => {
    "shop_id": shopId,
    "sifaris_kodu": sifarisKodu,
    "username": username,
    "sessionID": sessionId,
    "sessionEmail": sessionEmail,
    "pay_select": paySelect,
    "adress": adress,
    "price": price,
    "quantity": quantity,
    "color": color,
    "ax": ax,
    "cyl": cyl,
    "sph": sph,
    "lenstype": lenstype,
    "pro_image": proImage,
    "pro_name": proName,
    "activation": activation,
    "data": data,
  };
}

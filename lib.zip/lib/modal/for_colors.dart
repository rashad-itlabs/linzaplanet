// To parse this JSON data, do
//
//     final lensColors = lensColorsFromJson(jsonString);

import 'dart:convert';

List<LensColors> lensColorsFromJson(String str) => List<LensColors>.from(json.decode(str).map((x) => LensColors.fromJson(x)));

String lensColorsToJson(List<LensColors> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class LensColors {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String brandName;
  String seflink;

  LensColors({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.brandName,
    required this.seflink,
  });

  factory LensColors.fromJson(Map<String, dynamic> json) => LensColors(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    brandName: json["brand_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "brand_name": brandName,
    "seflink": seflink,
  };
}

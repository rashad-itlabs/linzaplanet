// To parse this JSON data, do
//
//     final brends = brendsFromJson(jsonString);

import 'dart:convert';

List<Brends> brendsFromJson(String str) => List<Brends>.from(json.decode(str).map((x) => Brends.fromJson(x)));

String brendsToJson(List<Brends> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Brends {
  String brendName;
  String seflink;

  Brends({
    required this.brendName,
    required this.seflink,
  });

  factory Brends.fromJson(Map<String, dynamic> json) => Brends(
    brendName: json["brend_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "brend_name": brendName,
    "seflink": seflink,
  };
}

// To parse this JSON data, do
//
//     final whiteColors = whiteColorsFromJson(jsonString);

import 'dart:convert';

List<WhiteColors> whiteColorsFromJson(String str) => List<WhiteColors>.from(json.decode(str).map((x) => WhiteColors.fromJson(x)));

String whiteColorsToJson(List<WhiteColors> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class WhiteColors {
  String id;
  String proName;
  String proImage;
  String proPrice;
  String position;
  String brandName;
  String seflink;

  WhiteColors({
    required this.id,
    required this.proName,
    required this.proImage,
    required this.proPrice,
    required this.position,
    required this.brandName,
    required this.seflink,
  });

  factory WhiteColors.fromJson(Map<String, dynamic> json) => WhiteColors(
    id: json["id"],
    proName: json["pro_name"],
    proImage: json["pro_image"],
    proPrice: json["pro_price"],
    position: json["position"],
    brandName: json["brand_name"],
    seflink: json["seflink"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "pro_name": proName,
    "pro_image": proImage,
    "pro_price": proPrice,
    "position": position,
    "brand_name": brandName,
    "seflink": seflink,
  };
}
